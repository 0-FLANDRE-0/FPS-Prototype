"""Side update: EOTECH XPS3 holographic + Trijicon ACOG TA31 on M4, and asset recompression.
Applied on top of patch.py output.  usage: patch_optics.py in.html out.html"""
import sys, base64
src, dst = sys.argv[1], sys.argv[2]
t = open(src, encoding='utf-8').read()
def rep(a, b, count=1):
    global t
    n = t.count(a)
    assert n == count, (n, a[:120])
    t = t.replace(a, b)

# ---------------------------------------------------------------- 1. optic definitions
XPS = ('cqbOptXps=Object.freeze({id:"eotech_xps3_0",name:"EOTECH XPS3-0 HWS",shortName:"XPS3",kind:"optic",'
       'size:Object.freeze({w:1,h:1}),weaponIds:Object.freeze(["m4a1"]),weightKg:.227,lengthM:.09525,'
       'windowM:Object.freeze([.03,.023]),reticleMOA:Object.freeze({ring:68,dot:1}),'
       'manufacturer:"EOTECH XPS3/XPS2 operator manual (8.0 oz, 3.75 in, window 30x23 mm); 68 MOA ring per EOTECH EXPS3 manual",'
       'installSeconds:.8,removeSeconds:.6,mountPosition:Object.freeze([0,.08426074878151618,.057]),'
       'blob:"optic-xps3-data",prefix:"XPS3",sight:"holo",variableZoom:!1,fixedMag:1,adsEyeReliefM:.173,'
       'axisHeightM:.04226,axisLengthM:.01438})')
ACOG = ('cqbOptAcog=Object.freeze({id:"trijicon_ta31",name:"Trijicon ACOG TA31 4\\xD732",shortName:"ACOG 4\\xD7",kind:"optic",'
        'size:Object.freeze({w:1,h:2}),weaponIds:Object.freeze(["m4a1"]),weightKg:.42241,lengthM:.15189,'
        'manufacturer:"https://www.trijicon.com/products/details/ta31-d-100309",'
        'installSeconds:1,removeSeconds:.8,mountPosition:Object.freeze([0,.08426074878151618,.192]),'
        'blob:"optic-acog-data",prefix:"ACOG",sight:"pip",variableZoom:!1,fixedMag:4,adsEyeReliefM:.0381,'
        'axisHeightM:.0396,axisLengthM:.12552})')
rep('installSeconds:1,removeSeconds:.8,mountPosition:Object.freeze([0,.08426074878151618,.145])}),Pk=Object.freeze({[rQ.id]:rQ}),',
    'installSeconds:1,removeSeconds:.8,mountPosition:Object.freeze([0,.08426074878151618,.145]),blob:"optic-data",prefix:"Vudu",sight:"pip",variableZoom:!0,adsEyeReliefM:.09,axisHeightM:.04033210855889871,axisLengthM:.24894691887253503}),'
    + XPS + ',' + ACOG + ',Pk=Object.freeze({[rQ.id]:rQ,[cqbOptXps.id]:cqbOptXps,[cqbOptAcog.id]:cqbOptAcog}),')

# ---------------------------------------------------------------- 2. aim geometry per optic
rep('sightAxis:new x(0,0,-1),sightCorrection:new dI},ja=class',
    'sightAxis:new x(0,0,-1),sightCorrection:new dI},cqbOptGeoCache={},cqbOptGeo=d=>cqbOptGeoCache[d.id]||(cqbOptGeoCache[d.id]=d.id===rQ.id?Wk:(()=>{let r=new x(...d.mountPosition).add(new x(0,d.axisHeightM,0));return{rear:r,front:r.clone().add(new x(0,0,-d.axisLengthM)),sightAxis:new x(0,0,-1),sightCorrection:new dI}})()),ja=class')
rep('setOptic(A){this.opticActive=!!(A&&this.weaponId==="m4a1"),this.geometry=this.opticActive?Wk:this.ironGeometry}',
    'setOptic(A){this.opticDef=A&&A.id&&this.weaponId==="m4a1"?A:null,this.opticActive=!!this.opticDef,this.geometry=this.opticActive?cqbOptGeo(this.opticDef):this.ironGeometry}')
rep('Math.max(.045,(this.opticActive?wC.adsEyeReliefM:Bi.eyeRelief)-this.kick*.6)', 'Math.max(this.opticActive?Math.min(.045,this.opticDef.adsEyeReliefM*.8):.045,(this.opticActive?this.opticDef.adsEyeReliefM:Bi.eyeRelief)-this.kick*.6)')
rep('r.setOptic(!!l.optic),l.action||S1(l.optic,DA.opticZoom,Sg)',
    'r.setOptic(Ei(l.optic)),l.action||!Ei(l.optic)?.variableZoom||S1(l.optic,DA.opticZoom,Sg)')
rep('EI("opticControls").hidden=!l.optic,', 'EI("opticControls").hidden=!Ei(l.optic)?.variableZoom,')
# focus zoom follows whichever magnified optic is mounted
rep('let oM=l.weapon?.definitionId==="m4a1"&&l.optic?.definitionId===rQ.id?Math.min(6,Math.max(1,l.optic.magnification??1)):1,',
    'let oP=l.weapon?.definitionId==="m4a1"?Ei(l.optic):null,oM=oP?Math.min(6,Math.max(1,oP.fixedMag??l.optic.magnification??1)):1,')
rep('oT=sn(oM).apparentTan/wC.focusFill', 'oT=(oP?.id===cqbOptAcog.id?cqbOptAcogP.sn:sn)(oM).apparentTan/wC.focusFill')
rep('"Vudu\\uB294 M4\\uC5D0\\uB9CC', '"\\uC774 \\uC870\\uC900\\uACBD\\uC740 M4\\uC5D0\\uB9CC')

# ---------------------------------------------------------------- 3. crate items
rep('A.cell=this.canPlace(BB,A,{x:5,y:4})?{x:5,y:4}:this.findCell(BB,A),this.items.set(A.instanceId,A),',
    'A.cell=this.canPlace(BB,A,{x:5,y:4})?{x:5,y:4}:this.findCell(BB,A),this.items.set(A.instanceId,A),'
    '[["optic-xps3-01",cqbOptXps],["optic-acog-01",cqbOptAcog]].forEach(([o,d])=>{let g={instanceId:o,kind:"optic",definitionId:d.id,owner:BB};g.cell=this.findCell(BB,g),g.cell&&this.items.set(o,g)}),')

# ---------------------------------------------------------------- 4. generic PiP optic (Vudu + ACOG)
ACOG_RET = r'''
 float segment(vec2 p,vec2 a,vec2 b){vec2 ab=b-a;return length(p-a-ab*clamp(dot(p-a,ab)/dot(ab,ab),0.0,1.0));}
 float boxd(vec2 p,vec2 c,vec2 h){vec2 d=abs(p-c)-h;return length(max(d,0.0))+min(max(d.x,d.y),0.0);}
 float cover(float d,float aa){return 1.0-smoothstep(-aa*.5,aa*.5,d);}
 // Trijicon ACOG 4x32 .223 Chevron (TA31) - official dimension sheet, MOA, chevron tip = 100 m zero.
 vec3 reticle(vec3 sourceColor,vec2 ndc,float tangent){
   vec2 q=atan(ndc*tangent)/2.908882e-4;float aa=max(max(fwidth(q.x),fwidth(q.y)),.02),hw=max(.2,aa*.5);
   float L=4.937,dOut=max((4.1*abs(q.x)+2.75*q.y)/L,-4.1-q.y),dIn=(4.1*abs(q.x)+2.75*(q.y+2.0))/L,chev=max(dOut,-dIn);
   float post1=boxd(q,vec2(0.0,-8.0),vec2(hw,3.6)),post2=boxd(q,vec2(0.0,-15.45),vec2(hw,3.85)),post3=boxd(q,vec2(0.0,-27.55),vec2(hw,8.25));
   float b4=boxd(q,vec2(0.0,-7.8),vec2(2.1,hw)),b5=boxd(q,vec2(0.0,-12.6),vec2(1.65,hw)),b6=boxd(q,vec2(0.0,-18.7),vec2(1.4,hw)),b7=boxd(q,vec2(0.0,-26.4),vec2(1.2,hw)),b8=boxd(q,vec2(0.0,-35.8),vec2(1.05,hw));
   vec2 n4=q-vec2(4.9,-7.8),n6=q-vec2(4.7,-18.7);float sw=max(.18,aa*.5);
   float g4=min(min(segment(n4,vec2(.45,1.4),vec2(-.85,-.35)),segment(n4,vec2(-.85,-.35),vec2(.85,-.35))),segment(n4,vec2(.45,1.4),vec2(.45,-1.4)))-sw;
   float g6=min(segment(n6,vec2(.55,1.35),vec2(-.62,-.45)),abs(length(n6-vec2(0.0,-.62))-.72))-sw;
   float bright=min(min(chev,post1),min(b4,g4)),dim=min(post2,min(b5,b6)),dark=min(post3,min(min(b7,b8),g6));
   vec3 color=mix(sourceColor,vec3(.003),cover(dark,aa));
   color=mix(color,vec3(.30,.02,.018),cover(dim,aa));
   color+=vec3(.55,.03,.02)*exp(-pow(max(bright,0.0)/.9,2.0))*.35;
   return mix(color,vec3(.95,.07,.04),cover(bright,aa));
 }
'''
cs_start = t.index('function cS({mount:B,markers:A,pack:I}){')
cs_end = t.index('async function hS(B,A){')
body = t[cs_start:cs_end]
body = body.replace('function cS({mount:B,markers:A,pack:I}){', 'function cS({mount:B,markers:A,pack:I,P=cqbOptVuduP}){', 1)
nwc = body.count('wC.'); body = body.replace('wC.', 'P.')
assert body.count('${lS}') == 1; body = body.replace('${lS}', '${P.reticle}')
assert body.count('sn(Y.optic?.magnification??1)') == 1
body = body.replace('sn(Y.optic?.magnification??1)', 'P.sn(P.fixedMag??Y.optic?.magnification??1)')
assert body.count('h1(J.toArray(),aA.magnification)') == 1
body = body.replace('h1(J.toArray(),aA.magnification)', 'P.h1(J.toArray(),aA.magnification)')
g0 = body.index('let e=I.getObjectByName("Glass_low_Glass_0"),a=e.geometry;')
g1 = body.index('e.geometry.setIndex(r);', g0) + len('e.geometry.setIndex(r);')
glass = body[g0:g1]
glass_new = ('let e=P.glassName?I.getObjectByName(P.glassName):null,a=e?.geometry;if(e){'
             + glass[len('let e=I.getObjectByName("Glass_low_Glass_0"),a=e.geometry;'):] + '}')
body = body[:g0] + glass_new + body[g1:]
assert body.count('e.geometry.dispose(),e.geometry=a,') == 1
body = body.replace('e.geometry.dispose(),e.geometry=a,', 'e&&(e.geometry.dispose(),e.geometry=a),')
assert body.count('reticle:"SR3 dimensioned inner BDC; outer speed ring deferred"') == 1
body = body.replace('reticle:"SR3 dimensioned inner BDC; outer speed ring deferred"', 'reticle:P.reticleName')
print('cS wC->P replacements', nwc)

PRE = ('var cqbOptVuduP=Object.assign({},wC,{sn:sn,h1:h1,reticle:lS,glassName:"Glass_low_Glass_0",reticleName:"SR3 dimensioned inner BDC; outer speed ring deferred"}),'
       'cqbOptAcogRet=`' + ACOG_RET + '`,'
       'cqbOptAcogP=(()=>{let k=Math.tan(3.5*Math.PI/180),P=Object.assign({},wC,{fixedMag:4,ocularRadiusM:.0115,adsEyeReliefM:.0381,axialFadeM:.012,'
       'objectiveDiameterM:.032,distortion:Object.freeze([-.01,-.01]),chroma:.004,vignette:.18,reticle:cqbOptAcogRet,glassName:null,'
       'reticleName:"Trijicon 4x32 .223 Chevron BDC (TA31), official MOA dimension sheet, chevron tip zero 100 m",'
       'source:"https://www.trijicon.com/uploads/product-uploads/product-downloads/223_Chevron_Reticle_Dimensions4x32.pdf",'
       'tuning:"post/bar line 0.4 MOA, numeral size/position and illumination split read from sheet proportions; eyebox fade 12 mm game tuning"});'
       'P.sn=m=>({magnification:4,trueTan:k,apparentTan:4*k,trueFovRad:2*Math.atan(k),apparentFovRad:2*Math.atan(4*k),exitPupilDiameterM:.00813,eyeReliefM:[.0381,.0381]});'
       'P.h1=(B,A)=>cqbOptH1(P,B,A);return P})();'
       'function cqbOptH1(P,B,A){let I=P.sn(A),[g,C]=I.eyeReliefM,Q=B[2],i=Math.hypot(B[0],B[1]),E=Math.max(g-Q,Q-C,0),e=Ce(1-E/P.axialFadeM,0,1),a=P.eyePupilRadiusM,t=I.exitPupilDiameterM/2,r=e>0?xk(a*e,t,i)/(Math.PI*a*a):0;'
       'return{axialM:Q,lateralM:i,axialAperture:e,coverage:r,exitPupilDiameterM:I.exitPupilDiameterM,visible:Q>.01&&r>.001}}')

# ---------------------------------------------------------------- 5. holographic sight
HOLO_FS = r'''varying vec3 vWorld;uniform vec4 qInv;uniform vec3 origin;uniform float scale,brightness;
 vec3 rot(vec4 q,vec3 v){return v+2.0*cross(q.xyz,cross(q.xyz,v)+q.w*v);}
 float segment(vec2 p,vec2 a,vec2 b){vec2 ab=b-a;return length(p-a-ab*clamp(dot(p-a,ab)/dot(ab,ab),0.0,1.0));}
 void main(){
  vec3 d=rot(qInv,normalize(vWorld-cameraPosition)),lp=rot(qInv,vWorld-origin)/max(scale,.001);
  // Reticle lives at infinity on the sight axis: only the ray direction matters (parallax free),
  // and it is seen wherever the line of sight passes through the window.
  vec2 q=vec2(atan(d.x,-d.z),atan(d.y,-d.z))/2.908882e-4;
  float aa=max(max(fwidth(q.x),fwidth(q.y)),.05),hw=max(.5,aa*.5),r=length(q);
  float ring=abs(r-34.0)-hw,dt=r-max(.5,aa*.5);
  float tk=min(min(segment(q,vec2(0.0,34.0),vec2(0.0,42.0)),segment(q,vec2(0.0,-34.0),vec2(0.0,-42.0))),min(segment(q,vec2(34.0,0.0),vec2(42.0,0.0)),segment(q,vec2(-34.0,0.0),vec2(-42.0,0.0))))-hw;
  float dm=min(min(ring,dt),tk),m=1.0-smoothstep(-aa*.5,aa*.5,dm),glow=exp(-pow(max(dm,0.0)/1.6,2.0))*.22;
  float sp=fract(sin(dot(floor(gl_FragCoord.xy*.5),vec2(12.9898,78.233)))*43758.5453);
  float rear=step(-.004,lp.z),rm=clamp(m*(.82+.3*sp)+glow,0.0,1.0)*rear;
  float fres=.04+.5*pow(1.0-abs(d.z),5.0),sky=smoothstep(-.1,.5,d.y);
  vec3 env=mix(vec3(.05,.045,.04),vec3(.62,.68,.74),sky),tint=vec3(.42,.5,.56)*.10+env*fres*vec3(.75,.95,.85);
  gl_FragColor=vec4(mix(tint,vec3(1.0,.02,.015)*brightness,rm),mix(.09+fres*.6,1.0,rm));
  #include <tonemapping_fragment>
  #include <colorspace_fragment>
 }'''
HOLO = ('function cqbOptHolo({mount:B,markers:A,pack:I,def:D}){let G=null;I.traverse(t=>{t.isMesh&&t.material?.name==="XPS3_Glass"&&(G=t)});'
        'let U={qInv:{value:new dI},origin:{value:new x},scale:{value:1},brightness:{value:1.5}},'
        'O=new OC({uniforms:U,transparent:!0,depthWrite:!1,side:2,toneMapped:!0,'
        'vertexShader:"varying vec3 vWorld; void main(){vec4 w=modelMatrix*vec4(position,1.0);vWorld=w.xyz;gl_Position=projectionMatrix*viewMatrix*w;}",'
        'fragmentShader:`' + HOLO_FS + '`}),M0=G?.material;G&&(G.material=O,G.renderOrder=5);'
        'let q=new dI,w=new x,M={pip:!1,rendered:!1,eligible:!1,kind:"holo",magnification:1,reticle:"EOTECH 68 MOA ring + 1 MOA dot, quadrant ticks (tick length/line width tuning)",windowM:D.windowM};'
        'function H({eyeCamera:R,inventory:Y,ads:V}){B.updateWorldMatrix(!0,!0),B.getWorldQuaternion(q),U.qInv.value.copy(q).invert(),A.window.getWorldPosition(U.origin.value),U.scale.value=B.getWorldScale(w).x;'
        'M={...M,ads:V,eye:R.getWorldPosition(new x).toArray(),window:U.origin.value.toArray(),axis:new x(0,0,-1).applyQuaternion(q).toArray(),glass:!!G}}'
        'return{update:H,render(){},dispose(){O.dispose(),G&&M0&&(G.material=M0)},projectWorldPoint:R=>R,surface:G,camera:null,snapshot:()=>({...M})}}')
t = t[:cs_start] + PRE + HOLO + body + t[cs_end:]

# ---------------------------------------------------------------- 6. loader: three optics, one dispatcher
h0 = t.index('async function hS(B,A){')
h1i = t.index('zeroing:!1,optics:e.snapshot()})}}', h0) + len('zeroing:!1,optics:e.snapshot()})}}')
HS = ('async function hS(B,A){let i=B.getObjectByName("rear_sight001"),U=[];'
      'for(let d of[rQ,cqbOptXps,cqbOptAcog]){let I=document.getElementById(d.blob).textContent.trim(),g=Uint8Array.from(atob(I),t=>t.charCodeAt(0)),C=await new UB().parseAsync(g.buffer,""),Q=new pg;'
      'Q.name=d===rQ?"M4OpticMount":"M4OpticMount_"+d.prefix,Q.matrixAutoUpdate=!1,Q.matrix.copy(A.clone().invert().multiply(new LI().makeTranslation(...d.mountPosition))),Q.add(C.scene),B.add(Q),Q.visible=!1,'
      'C.scene.traverse(t=>{t.isMesh&&(t.frustumCulled=!1,t.material.transparent&&(t.material.depthWrite=!1))});'
      'let E=Object.fromEntries((d.sight==="holo"?["window","windowFront","mountBottom"]:["ocular","objective","mountBottom"]).map(t=>[t,C.scene.getObjectByName(d.prefix+"_"+t)])),'
      'e=d.sight==="holo"?cqbOptHolo({mount:Q,markers:E,pack:C.scene,def:d}):cS({mount:Q,markers:E,pack:C.scene,P:d===rQ?cqbOptVuduP:cqbOptAcogP});'
      'U.push({def:d,mount:Q,pack:C.scene,markers:E,optics:e})}'
      'let K=U[0],F=t=>t?.weapon?.definitionId==="m4a1"&&U.find(u=>t.optic?.definitionId===u.def.id)||null;'
      'function a(t){let r=F(t);for(let u of U)u.mount.visible=u===r;i&&(i.visible=!r),r&&(K=r)}'
      'let e={update(o){let r=F(o.inventory);r&&(K=r);for(let u of U)u.optics.update(u===r?o:{...o,ads:0})},render(...o){for(let u of U)u.optics.render(...o)},dispose(){for(let u of U)u.optics.dispose()},'
      'projectWorldPoint:o=>K.optics.projectWorldPoint(o),snapshot:()=>K.optics.snapshot(),get camera(){return K.optics.camera},get surface(){return K.optics.surface}};'
      'return{get mount(){return K.mount},get pack(){return K.pack},sync:a,optics:e,snapshot:()=>(K.mount.updateWorldMatrix(!0,!0),{id:K.def.id,visible:K.mount.visible,rearIronVisible:i?.visible,'
      'markers:Object.fromEntries(Object.entries(K.markers).map(([t,r])=>[t,r.getWorldPosition(new x).toArray()])),opticalAxis:new x(0,0,-1).applyQuaternion(K.mount.getWorldQuaternion(new dI)).toArray(),'
      'pip:K.optics.snapshot().pip,zeroing:!1,optics:K.optics.snapshot()})}}')
t = t[:h0] + HS + t[h1i:]

# ---------------------------------------------------------------- 7. credits
CRED = ('<h2>EOTECH XPS3-0 HWS</h2><p>모델 제작: <a href="https://sketchfab.com/Andruxa-snajper" target="_blank" rel="noopener">Andruxa-snajper</a></p>'
        '<p><a href="https://sketchfab.com/3d-models/eotech-xps3-0-holographic-sight-ver40-4efb1b416b6a413ebaeb0ed60fd3c2a2" target="_blank" rel="noopener">Sketchfab 원본</a> · '
        '<a href="https://sketchfab.com/licenses" target="_blank" rel="noopener">Sketchfab Standard</a></p>'
        '<p class="credit-note">95.25 mm 길이와 게임 좌표계로 정렬하고 유리 재질을 분리했습니다. 모델에 그려진 조준선 대신 무한원 홀로그램 조준선(68 MOA 링·1 MOA 점)을 셰이더로 그립니다. 텍스처를 WebP로 변환했습니다. 비공개 개인 프로젝트용입니다.</p>'
        '<h2>Trijicon ACOG TA31 4×32</h2><p>모델 제작: <a href="https://sketchfab.com/jeandiz" target="_blank" rel="noopener">Mateusz Woliński</a></p>'
        '<p><a href="https://sketchfab.com/3d-models/acog-b2eedf78173343c2b9e47d94618824e7" target="_blank" rel="noopener">Sketchfab 원본</a> · '
        '<a href="https://creativecommons.org/licenses/by-nc/4.0/" target="_blank" rel="noopener">CC BY-NC 4.0</a></p>'
        '<p class="credit-note">RMR·RMR 마운트·킬플래시·모델 조준선·접안 유리를 제거하고 151.89 mm 길이로 정렬했습니다. 투과 재질을 일반 재질로 바꾸고 텍스처를 WebP로 변환했습니다. 비상업 라이선스이므로 비공개 개인 프로젝트에서만 사용합니다.</p>'
        '<p class="credit-note">.223 Chevron 조준선: <a href="https://www.trijicon.com/uploads/product-uploads/product-downloads/223_Chevron_Reticle_Dimensions4x32.pdf" target="_blank" rel="noopener">Trijicon 공식 치수 도면</a> · 비공개 개인 프로젝트용 재현입니다.</p>')
rep('<h2>Soldier Character</h2>', CRED + '<h2>Soldier Character</h2>')

# ---------------------------------------------------------------- 8. assets
RC = '/tmp/claude-0/-home-claude/46d90bd5-b514-5e3f-b91e-5cd448cd7a9c/scratchpad/za/rc/'
for name in ['weapon-data', 'fps-data', 'shared-arms-data', 'optic-data', 'soldier-data']:
    s = t.index(f'<script id="{name}" type="application/octet-stream">'); s2 = t.index('>', s) + 1; e = t.index('</script>', s2)
    t = t[:s2] + base64.b64encode(open(RC + name + '.glb', 'rb').read()).decode() + t[e:]
extra = ''.join(f'<script id="{n}" type="application/octet-stream">' + base64.b64encode(open(RC + n + '.glb', 'rb').read()).decode() + '</script>\n'
                for n in ['optic-xps3-data', 'optic-acog-data'])
rep('<script id="soldier-data"', extra + '<script id="soldier-data"')
open(dst, 'w', encoding='utf-8').write(t)
print('ok', len(t.encode()))
