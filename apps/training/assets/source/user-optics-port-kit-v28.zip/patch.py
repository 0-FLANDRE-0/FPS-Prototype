import sys
src,dst,hook=sys.argv[1],sys.argv[2],sys.argv[3]=='1'
t=open(src,encoding='utf-8').read()
def rep(a,b):
    global t
    n=t.count(a); assert n==1,(n,a[:80]); t=t.replace(a,b)
# 1 defaults / ranges / formatter
rep('fov:66,lensStrength:70,lensFov:120,stepImpact:100','fov:66,lensStrength:70,lensFov:120,scopeFocus:100,stepImpact:100')
rep('lensFov:[90,140],stepImpact:[0,150]','lensFov:[90,140],scopeFocus:[0,100],stepImpact:[0,150]')
rep('lensFov:DA=>`${DA}\\xB0`,stepImpact:','lensFov:DA=>`${DA}\\xB0`,scopeFocus:DA=>`${DA}%`,stepImpact:')
# 2 settings row after the fov row
row='<div class="setting-row"><label for="fov">시야각 <output id="fovValue">66°</output></label><input id="fov" type="range" min="60" max="85" step="1" value="66"></div>'
rep(row,row+'       <div class="setting-row"><label for="scopeFocus">조준경 집중 <output id="scopeFocusValue">100%</output></label><input id="scopeFocus" type="range" min="0" max="100" step="1" value="100"></div>')
# 3 focus FOV while looking through the magnified optic
old='let j=Q.lensStrength>0?y1(B.camera.aspect,Q.lensStrength,Q.lensFov,r.ads):null;B.lens.setParameters(j);let $=j?j.verticalFov:Tg.lerp(Q.fov,Q.fov-14,r.ads);'
new=('let oM=l.weapon?.definitionId==="m4a1"&&l.optic?.definitionId===rQ.id?Math.min(6,Math.max(1,l.optic.magnification??1)):1,'
     'oF=r.ads*Q.scopeFocus/100*Math.log(oM)/Math.log(6),oT=sn(oM).apparentTan/wC.focusFill,oD=180/Math.PI,'
     'j0=Q.lensStrength>0?y1(B.camera.aspect,Q.lensStrength,Q.lensFov,r.ads):null,'
     'j=j0&&oF>0?y1(B.camera.aspect,Q.lensStrength*(1-oF),Tg.lerp(Q.lensFov*(1-.2*r.ads),2*Math.atan(oT*B.camera.aspect)*oD,oF)/(1-.2*r.ads),r.ads):j0;'
     'B.lens.setParameters(j);let $0=j0?j0.verticalFov:Tg.lerp(Q.fov,Q.fov-14,r.ads),$=j?j.verticalFov:Tg.lerp($0,2*Math.atan(oT)*oD,oF);'
     'r.opticLookScale=Math.tan($/oD/2)/Math.tan($0/oD/2);')
rep(old,new)
# 4 look sensitivity follows the focus zoom only (magnification itself still swings the image)
rep('r.look(H,b,q.ads),H=b=0','r.look(H*(r.opticLookScale??1),b*(r.opticLookScale??1),q.ads),H=b=0')
# 5 zoom travel in log space (equal perceived steps), same 1->6 full travel time
rep('B.magnification=Ce((B.magnification??1)+Ce(A||0,-1,1)*5*I/wC.zoomTravelSeconds,1,6)',
    'B.magnification=Ce((B.magnification??1)*Math.exp(Ce(A||0,-1,1)*Math.log(6)*I/wC.zoomTravelSeconds),1,6)')
rep('adsEyeReliefM:.09,zoomTravelSeconds:.4,','adsEyeReliefM:.09,zoomTravelSeconds:.4,zoomLaw:"log",focusFill:.62,focusLaw:"ln(m)/ln(6), tuning",')

# ---- optical look (v27.2) ----
rep('transmission:{value:wC.transmission},vignette:{value:wC.vignette}},',
    'transmission:{value:wC.transmission},vignette:{value:wC.vignette},distortion:{value:wC.distortion[0]},chroma:{value:wC.chroma},edgeBlur:{value:wC.edgeBlur},exitPupilZ:{value:wC.adsEyeReliefM},glare:{value:wC.glare}},')
rep('uniform float radius,apparentTan,trueTan,exitRadius,pupilRadius,axialAperture,transmission,vignette;\n   ${lS}\n   void main(){',
    'uniform float radius,apparentTan,trueTan,exitRadius,pupilRadius,axialAperture,transmission,vignette,distortion,chroma,edgeBlur,exitPupilZ,glare;\n   ${lS}\n'
    '   vec3 lensSample(vec2 n){float r2=dot(n,n);vec2 d=n*(1.0+distortion*r2);float ca=chroma*r2,b=edgeBlur*r2*r2*.7071;vec3 c=vec3(0.0);\n'
    '    for(int k=0;k<5;k++){vec2 o=k==0?vec2(0.0):vec2((k==1||k==2)?b:-b,(k==1||k==3)?b:-b);\n'
    '     c.r+=texture2D(source,(d*(1.0+ca)+o)*.5+.5).r;c.g+=texture2D(source,(d+o)*.5+.5).g;c.b+=texture2D(source,(d*(1.0-ca)+o)*.5+.5).b;}\n'
    '    return c*.2;}\n'
    '   void main(){')
rep('    float aa=max(fwidth(length(ndc)),.001),field=1.0-smoothstep(axialAperture-aa,axialAperture+aa,length(ndc));\n    float pupilDistance=length(ndc*pupilRadius+eye.xy);\n    float pupilAA=max(fwidth(pupilDistance),.00001),pupil=1.0-smoothstep(exitRadius-pupilAA,exitRadius+pupilAA,pupilDistance);\n    vec3 color=vec3(.003,.006,.007);\n    if(imageEnabled>.5){color=texture2D(source,ndc*.5+.5).rgb*transmission*(1.0-vignette*pow(clamp(length(ndc),0.0,1.0),4.0));color=reticle(color,ndc,trueTan);color*=field*pupil;}\n    gl_FragColor=vec4(color,1.0);',
    '    float rn=length(ndc),aa=max(fwidth(rn),.001),soft=max(aa,.012);\n'
    '    // Field stop: slightly soft edge with a thin lateral-colour fringe.\n'
    '    vec3 field=vec3(1.0-smoothstep(axialAperture*.997-soft,axialAperture*.997+soft,rn),1.0-smoothstep(axialAperture-soft,axialAperture+soft,rn),1.0-smoothstep(axialAperture*1.003-soft,axialAperture*1.003+soft,rn));\n'
    '    // Each field bundle crosses the eye plane displaced by axial eye-relief error; the eye pupil\n'
    '    // area sliding off the exit pupil gives a soft swimming crescent instead of a hard cut.\n'
    '    vec2 ray=eye.xy+ndc*(pupilRadius*.8+apparentTan*abs(eye.z-exitPupilZ));float pd=length(ray);\n'
    '    float pupil=1.0-smoothstep(exitRadius-pupilRadius*.5,exitRadius+pupilRadius*.5,pd);\n'
    '    vec3 color=vec3(.003,.006,.007);\n'
    '    if(imageEnabled>.5){vec2 dn=ndc*(1.0+distortion*rn*rn);color=lensSample(ndc)*transmission*(1.0-vignette*pow(clamp(rn,0.0,1.0),3.0));color=reticle(color,dn,trueTan);color*=field*pupil;}\n'
    '    // Eyepiece glass: AR-coated residual reflection of the surroundings and a rim glint.\n'
    '    vec2 gq=plane/radius;float gr=length(gq);vec3 vd=normalize(vec3(plane-eye.xy,-max(eye.z,.001)));vec3 nr=normalize(vec3(gq*.35,1.0));vec3 rd=reflect(vd,nr);\n'
    '    float sky=smoothstep(-.15,.55,rd.y);vec3 env=mix(vec3(.05,.045,.04),vec3(.62,.68,.74),sky);float fres=.012+.06*pow(1.0-abs(dot(vd,nr)),5.0);\n'
    '    color+=env*vec3(.55,.9,.6)*fres*glare*(imageEnabled>.5&&rn<axialAperture?.5:1.0);color+=vec3(.5,.55,.6)*glare*.08*smoothstep(.86,.96,gr)*(1.0-smoothstep(.96,1.0,gr))*(.4+.6*sky);\n'
    '    gl_FragColor=vec4(color,1.0);')
# illuminated reticle: soft glow around ring/dot
rep('   vec3 color=mix(sourceColor,vec3(.002),black);\n   return mix(color,vec3(.65,.004,.007),max(ring,dotMask));',
    '   vec3 color=mix(sourceColor,vec3(.002),black);\n'
    '   float gw=max(aa*2.5,.00025),glow=exp(-pow(abs(length(p)-.002)/gw,2.0));if(p.y<0.0&&abs(p.x)<.001)glow=0.0;glow=max(glow,exp(-pow(length(p)/(gw*1.4),2.0)));\n'
    '   color+=vec3(.42,.01,.012)*glow*.45;\n'
    '   return mix(color,vec3(.65,.004,.007),max(ring,dotMask));')
# per-frame distortion follows magnification (1x fishbowl -> 6x mild pincushion)
rep('Q.eye.value.copy(J),Q.apparentTan.value=aA.apparentTan,',
    'Q.eye.value.copy(J),Q.distortion.value=wC.distortion[0]+(wC.distortion[1]-wC.distortion[0])*(aA.magnification-1)/5,Q.apparentTan.value=aA.apparentTan,')
# keep projected markers consistent with the new pupil model and distortion
rep('return Y.z<-1||Y.z>1||Math.hypot(Y.x,Y.y)>q||Math.hypot(Y.x*wC.eyePupilRadiusM+V.x,Y.y*wC.eyePupilRadiusM+V.y)>Q.exitRadius.value?null:B.localToWorld(E.position.clone().add(new x(V.x+Y.x*V.z*Q.apparentTan.value,V.y+Y.y*V.z*Q.apparentTan.value,0)))',
    'let oS=wC.eyePupilRadiusM*.8+Q.apparentTan.value*Math.abs(V.z-wC.adsEyeReliefM),oK=1/(1+Q.distortion.value*(Y.x*Y.x+Y.y*Y.y)),oX=Y.x*oK,oY=Y.y*oK;return Y.z<-1||Y.z>1||Math.hypot(oX,oY)>q||Math.hypot(V.x+oX*oS,V.y+oY*oS)>Q.exitRadius.value?null:B.localToWorld(E.position.clone().add(new x(V.x+oX*V.z*Q.apparentTan.value,V.y+oY*V.z*Q.apparentTan.value,0)))')
rep('transmission:.92,vignette:.08,','transmission:.92,vignette:.14,distortion:Object.freeze([.035,-.015]),chroma:.005,edgeBlur:.006,glare:2,opticalLookTuning:"vignette/distortion/chroma/edgeBlur/glare/glow are game tuning, not EOTECH data",')
if hook:
    k='window.CQBTraining=Object.freeze({snapshot:'
    rep(k,'window.__T={l,c,r,Q,B,A,I};'+k)
open(dst,'w',encoding='utf-8').write(t)
print('ok',len(t.encode()))
