import sys,io,json,os,subprocess
sys.path.insert(0,os.path.dirname(__file__))
import glbio
# policy: function(name, usage set, near: bool) -> mode
def mode_for(us,near):
    if any('specular' in x for x in us): return 'keep'
    if 'normal' in us: return 'nl:20' if near else 'q:90'
    if us & {'mr','ao'}: return 'q:90'
    if 'emis' in us: return 'q:92'
    if any('transmission' in x for x in us): return 'q:90'
    return 'q:92'  # base color
def recompress(src,dst,near,work,minbytes=60000,extra_webp=False):
    j,v=glbio.read(src); u=glbio.usage(j); os.makedirs(work,exist_ok=True); jobs=[]
    for i,im in enumerate(j.get('images',[])):
        d=v[im['bufferView']]; us=u.get(i,set()); m=mode_for(us,near)
        if m=='keep' or (len(d)<minbytes and im.get('mimeType')=='image/webp'): continue
        p=f'{work}/{i}.in'; open(p,'wb').write(d); jobs.append({'in':p,'out':f'{work}/{i}.webp','mode':m,'i':i})
    json.dump(jobs,open(f'{work}/jobs.json','w'))
    subprocess.check_call(['node',os.path.join(os.path.dirname(__file__),'enc.js'),f'{work}/jobs.json'])
    before=sum(map(len,v))
    for jb in jobs:
        n=open(jb['out'],'rb').read(); im=j['images'][jb['i']]
        if im.get('mimeType')=='image/webp' and len(n)>=len(v[im['bufferView']]): continue
        v[im['bufferView']]=n; im['mimeType']='image/webp'
    # if any PNG became webp, ensure textures use EXT_texture_webp
    if any(im.get('mimeType')=='image/webp' for im in j.get('images',[])):
        ext=set(j.get('extensionsUsed',[])); ext.add('EXT_texture_webp'); j['extensionsUsed']=sorted(ext)
        req=set(j.get('extensionsRequired',[])); req.add('EXT_texture_webp'); j['extensionsRequired']=sorted(req)
        for t in j.get('textures',[]):
            s=t.get('source', t.get('extensions',{}).get('EXT_texture_webp',{}).get('source'))
            if s is not None and j['images'][s].get('mimeType')=='image/webp':
                t.pop('source',None); t.setdefault('extensions',{})['EXT_texture_webp']={'source':s}
    out=glbio.write(j,v); open(dst,'wb').write(out)
    print(os.path.basename(src),before,'->',len(out))
if __name__=='__main__':
    recompress(sys.argv[1],sys.argv[2],sys.argv[3]=='near',sys.argv[4])
