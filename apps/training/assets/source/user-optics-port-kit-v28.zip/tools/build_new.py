import sys,json; sys.path.insert(0,'za/tools')
import glbio,build_optic as B,recompress,numpy as np
# ---------- XPS3 ----------
j,v=glbio.read('glb/462ffce4-eotech_xps3-0_holographic_sight_ver.4.0.glb')
s=0.09525/(7.0821+2.2891)
ref=(3.8464,5.66,-0.0247)
B.frame(j,'XPS3',[[0,0,-1],[0,1,0],[1,0,0]],s,ref,{'window':(3.8464,9.8179,-0.0247),'windowFront':(2.4313,9.8179,-0.0247),'mountBottom':ref})
# separate glass material
gm=json.loads(json.dumps(j['materials'][0])); gm['name']='XPS3_Glass'; j['materials'].append(gm)
for n in j['nodes']:
    if 'mesh' in n and j['nodes'].index(n)==3: pass
j['meshes'][0]['primitives'][0]['material']=len(j['materials'])-1
j['materials'][0]['alphaMode']='MASK'; j['materials'][0]['alphaCutoff']=0.5
j['asset']['extras']['derived']='CQB Training: meter frame (95.25 mm XPS3 length), rail/window markers, separate glass material, WebP textures'
j,v=B.gc(j,v); j,v=B.compact(j,v); open('za/xps3_frame.glb','wb').write(glbio.write(j,v))
recompress.recompress('za/xps3_frame.glb','za/rc/optic-xps3-data.glb',True,'za/work/xps3')
# ---------- ACOG ----------
j,v=glbio.read('glb/f742dc09-acog.glb')
B.drop_nodes(j,{'RMR','rds mount','killflash','reticle','glass front'})
s=0.15189/(655.7347+1380.8307)
ref=(-1385,-496,5.0)
B.frame(j,'ACOG',[[0,0,1],[0,1,0],[-1,0,0]],s,ref,{'ocular':(-1385,35,5.0),'objective':(298,35,5.0),'mountBottom':ref})
for m in j['materials']:
    ext=m.get('extensions',{}); ext.pop('KHR_materials_transmission',None)
    if not ext: m.pop('extensions',None)
    if m['name']=='acog': m['alphaMode']='MASK'; m['alphaCutoff']=0.5
    if m['name']=='glass_back':
        m['alphaMode']='BLEND'; m['pbrMetallicRoughness']={'baseColorFactor':[0.03,0.045,0.05,0.4],'metallicFactor':0.0,'roughnessFactor':0.05}
        m.pop('extensions',None); m.pop('normalTexture',None); m.pop('emissiveTexture',None); m.pop('occlusionTexture',None)
j['asset']['extras']['derived']='CQB Training: RMR/RDS mount/killflash/model reticle/ocular glass removed; meter frame (151.89 mm TA31 length), rail/ocular/objective markers; transmission removed; WebP textures'
j,v=B.gc(j,v); j,v=B.compact(j,v); open('za/acog_frame.glb','wb').write(glbio.write(j,v))
recompress.recompress('za/acog_frame.glb','za/rc/optic-acog-data.glb',True,'za/work/acog')
