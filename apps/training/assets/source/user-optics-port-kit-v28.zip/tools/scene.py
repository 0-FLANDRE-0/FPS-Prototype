import numpy as np, sys, os
sys.path.insert(0,os.path.dirname(__file__))
import glbio
CT={5126:np.float32,5123:np.uint16,5125:np.uint32,5121:np.uint8}
NC={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def acc(j,v,i):
    a=j['accessors'][i]; bv=j['bufferViews'][a['bufferView']]; d=v[a['bufferView']]
    dt=np.dtype(CT[a['componentType']]); n=NC[a['type']]; stride=bv.get('byteStride',0) or dt.itemsize*n
    off=a.get('byteOffset',0); cnt=a['count']
    buf=np.frombuffer(d,dtype=np.uint8)
    out=np.empty((cnt,n),dtype=dt)
    for k in range(cnt):
        out[k]=np.frombuffer(buf[off+k*stride:off+k*stride+dt.itemsize*n].tobytes(),dtype=dt)
    return out
def local(n):
    if 'matrix' in n: return np.array(n['matrix'],dtype=float).reshape(4,4).T
    T=np.eye(4); R=np.eye(4); S=np.eye(4)
    if 'translation' in n: T[:3,3]=n['translation']
    if 'rotation' in n:
        x,y,z,w=n['rotation']
        R[:3,:3]=[[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)],[2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)],[2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)]]
    if 'scale' in n: S[0,0],S[1,1],S[2,2]=n['scale']
    return T@R@S
def worlds(j):
    W={}
    def rec(i,M):
        W[i]=M@local(j['nodes'][i])
        for c in j['nodes'][i].get('children',[]): rec(c,W[i])
    for r in j['scenes'][0]['nodes']: rec(r,np.eye(4))
    return W
def mesh_points(j,v,W,i):
    n=j['nodes'][i]; pts=[]
    for p in j['meshes'][n['mesh']]['primitives']:
        P=acc(j,v,p['attributes']['POSITION']).astype(float)
        P=np.c_[P,np.ones(len(P))]@W[i].T
        pts.append(P[:,:3])
    return np.vstack(pts)
