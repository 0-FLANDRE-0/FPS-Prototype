// usage: node enc.js in out mode(nl:NN | q:NN | keep)
const sharp=require('/tmp/claude-0/-home-claude/46d90bd5-b514-5e3f-b91e-5cd448cd7a9c/scratchpad/za/node/node_modules/sharp');
const fs=require('fs');
(async()=>{const jobs=JSON.parse(fs.readFileSync(process.argv[2]));
for(const jb of jobs){let s=sharp(jb.in);if(jb.size)s=s.resize(jb.size,jb.size,{fit:'fill'});
 const [m,v]=jb.mode.split(':');let o;
 if(m==='nl')o=await s.webp({nearLossless:true,quality:+v,effort:6}).toBuffer();
 else if(m==='ll')o=await s.webp({lossless:true,effort:6}).toBuffer();
 else o=await s.webp({quality:+v,effort:6,alphaQuality:100}).toBuffer();
 fs.writeFileSync(jb.out,o);}
})().catch(e=>{console.error(e);process.exit(1)});
