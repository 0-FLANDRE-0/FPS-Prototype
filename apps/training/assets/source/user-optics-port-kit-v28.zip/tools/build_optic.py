import sys,os,json,copy,numpy as np
sys.path.insert(0,os.path.dirname(__file__))
import glbio,scene
def gc(j,v):
    # collect reachable nodes
    keep=set()
    def rec(i):
        keep.add(i); [rec(c) for c in j['nodes'][i].get('children',[])]
    for r in j['scenes'][0]['nodes']: rec(r)
    order=sorted(keep); nmap={o:i for i,o in enumerate(order)}
    nodes=[]
    for o in order:
        n=copy.deepcopy(j['nodes'][o])
        if 'children' in n: n['children']=[nmap[c] for c in n['children'] if c in nmap]
        nodes.append(n)
    j['nodes']=nodes; j['scenes'][0]['nodes']=[nmap[r] for r in j['scenes'][0]['nodes']]
    # meshes
    used=sorted({n['mesh'] for n in nodes if 'mesh' in n}); mmap={o:i for i,o in enumerate(used)}
    j['meshes']=[j['meshes'][o] for o in used]
    for n in nodes:
        if 'mesh' in n: n['mesh']=mmap[n['mesh']]
    # materials
    usedm=sorted({p['material'] for m in j['meshes'] for p in m['primitives'] if 'material' in p}); matmap={o:i for i,o in enumerate(usedm)}
    j['materials']=[j['materials'][o] for o in usedm]
    for m in j['meshes']:
        for p in m['primitives']:
            if 'material' in p: p['material']=matmap[p['material']]
    # textures
    def texrefs(obj,acc):
        if isinstance(obj,dict):
            if 'index' in obj and len(obj)<=4 and isinstance(obj['index'],int) and ('texCoord' in obj or 'scale' in obj or 'strength' in obj or 'extensions' in obj or len(obj)==1): acc.append(obj)
            for k,vv in obj.items():
                if k!='index': texrefs(vv,acc)
        elif isinstance(obj,list):
            for x in obj: texrefs(x,acc)
    refs=[]; texrefs(j['materials'],refs)
    usedt=sorted({r['index'] for r in refs}); tmap={o:i for i,o in enumerate(usedt)}
    for r in refs: r['index']=tmap[r['index']]
    j['textures']=[j['textures'][o] for o in usedt]
    srcs=lambda t: t.get('source', t.get('extensions',{}).get('EXT_texture_webp',{}).get('source'))
    usedi=sorted({srcs(t) for t in j['textures']}); imap={o:i for i,o in enumerate(usedi)}
    for t in j['textures']:
        if 'source' in t: t['source']=imap[t['source']]
        if 'EXT_texture_webp' in t.get('extensions',{}): t['extensions']['EXT_texture_webp']['source']=imap[t['extensions']['EXT_texture_webp']['source']]
    j['images']=[j['images'][o] for o in usedi]
    if 'samplers' in j: pass
    # accessors
    usedacc=set()
    for m in j['meshes']:
        for p in m['primitives']:
            usedacc.update(p['attributes'].values())
            if 'indices' in p: usedacc.add(p['indices'])
            for t in p.get('targets',[]): usedacc.update(t.values())
    for s in j.get('skins',[]):
        if 'inverseBindMatrices' in s: usedacc.add(s['inverseBindMatrices'])
    usedacc=sorted(usedacc); amap={o:i for i,o in enumerate(usedacc)}
    j['accessors']=[j['accessors'][o] for o in usedacc]
    for m in j['meshes']:
        for p in m['primitives']:
            p['attributes']={k:amap[a] for k,a in p['attributes'].items()}
            if 'indices' in p: p['indices']=amap[p['indices']]
    j.pop('animations',None)
    # buffer views
    usedbv=sorted({a['bufferView'] for a in j['accessors'] if 'bufferView' in a}|{im['bufferView'] for im in j['images']})
    bmap={o:i for i,o in enumerate(usedbv)}
    for a in j['accessors']:
        if 'bufferView' in a: a['bufferView']=bmap[a['bufferView']]
    for im in j['images']: im['bufferView']=bmap[im['bufferView']]
    j['bufferViews']=[j['bufferViews'][o] for o in usedbv]
    v=[v[o] for o in usedbv]
    # extensions used cleanup
    s=json.dumps(j)
    j['extensionsUsed']=[e for e in j.get('extensionsUsed',[]) if e in s.replace('"extensionsUsed"','')]
    return j,v
def drop_nodes(j,names):
    for n in j['nodes']:
        if 'children' in n: n['children']=[c for c in n['children'] if j['nodes'][c].get('name') not in names]
    j['scenes'][0]['nodes']=[r for r in j['scenes'][0]['nodes'] if j['nodes'][r].get('name') not in names]
def frame(j,prefix,R,scale,ref,markers):
    # R: 3x3 model->game rotation; game = scale*R*(p-ref)
    M=np.eye(4); M[:3,:3]=scale*np.array(R,float); M[:3,3]=-scale*np.array(R,float)@np.array(ref,float)
    roots=j['scenes'][0]['nodes']
    j['nodes'].append({'name':prefix+'_Meter_Frame','matrix':list(M.T.reshape(-1)),'children':roots})
    newroots=[len(j['nodes'])-1]
    for name,pos in markers.items():
        g=scale*np.array(R,float)@(np.array(pos,float)-np.array(ref,float))
        j['nodes'].append({'name':prefix+'_'+name,'translation':[float(x) for x in g]}); newroots.append(len(j['nodes'])-1)
        print(prefix,name,np.round(g,5))
    j['scenes'][0]['nodes']=newroots
def compact(j,v):
    CS={5126:4,5123:2,5125:4,5121:1,5122:2,5120:1}
    NCc={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
    newv=[]; newbv=[]
    for a in j['accessors']:
        if 'bufferView' not in a: continue
        bv=j['bufferViews'][a['bufferView']]; d=v[a['bufferView']]
        es=CS[a['componentType']]*NCc[a['type']]; stride=bv.get('byteStride',0) or es; off=a.get('byteOffset',0)
        out=bytearray()
        if stride==es: out+=d[off:off+es*a['count']]
        else:
            for k in range(a['count']): out+=d[off+k*stride:off+k*stride+es]
        nb={'buffer':0,'byteLength':len(out)}
        if 'target' in bv: nb['target']=bv['target']
        newbv.append(nb); newv.append(bytes(out)); a['bufferView']=len(newbv)-1; a['byteOffset']=0
    for im in j['images']:
        newbv.append({'buffer':0,'byteLength':len(v[im['bufferView']])}); newv.append(v[im['bufferView']]); im['bufferView']=len(newbv)-1
    j['bufferViews']=newbv
    return j,newv
