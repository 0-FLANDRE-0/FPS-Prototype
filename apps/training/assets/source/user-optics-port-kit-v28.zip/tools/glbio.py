import json,struct
def read(path_or_bytes):
    b=open(path_or_bytes,'rb').read() if isinstance(path_or_bytes,str) else path_or_bytes
    L=struct.unpack('<I',b[12:16])[0]; j=json.loads(b[20:20+L])
    o=20+L; BL,BT=struct.unpack('<II',b[o:o+8]); binc=b[o+8:o+8+BL]
    views=[binc[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']] for v in j['bufferViews']]
    return j,views
def write(j,views):
    out=bytearray()
    for i,v in enumerate(views):
        while len(out)%4: out.append(0)
        j['bufferViews'][i]['byteOffset']=len(out); j['bufferViews'][i]['byteLength']=len(v); j['bufferViews'][i]['buffer']=0
        out+=v
    while len(out)%4: out.append(0)
    j['buffers']=[{'byteLength':len(out)}]
    js=json.dumps(j,separators=(',',':')).encode()
    while len(js)%4: js+=b' '
    total=12+8+len(js)+8+len(out)
    return struct.pack('<III',0x46546C67,2,total)+struct.pack('<II',len(js),0x4E4F534A)+js+struct.pack('<II',len(out),0x004E4942)+bytes(out)
def usage(j):
    u={}
    texsrc=lambda t: (j['textures'][t].get('extensions',{}).get('EXT_texture_webp',{}).get('source', j['textures'][t].get('source')))
    for m in j.get('materials',[]):
        p=m.get('pbrMetallicRoughness',{})
        for k,tag in [('baseColorTexture','base'),('metallicRoughnessTexture','mr')]:
            if k in p: u.setdefault(texsrc(p[k]['index']),set()).add(tag)
        for k,tag in [('normalTexture','normal'),('occlusionTexture','ao'),('emissiveTexture','emis')]:
            if k in m: u.setdefault(texsrc(m[k]['index']),set()).add(tag)
        for e,ext in m.get('extensions',{}).items():
            for k,v in ext.items():
                if isinstance(v,dict) and 'index' in v: u.setdefault(texsrc(v['index']),set()).add(e+':'+k)
    return u
